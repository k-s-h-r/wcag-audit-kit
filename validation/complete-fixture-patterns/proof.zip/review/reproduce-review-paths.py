"""Run current regression cases against an unchanged function from a fixed commit."""
import ast
import subprocess
import sys
import unittest
from unittest.mock import patch
from pathlib import Path
root=Path('/workspace/wcag-audit-kit-github');sys.path[:0]=[str(root),str(root/'tests')]
from benchmarks import core
from test_benchmarks import ScoringTest
for commit,name,test in [
 ('a9028bc','program_predictions','test_relative_run_decodes_axe_and_keyboard_evidence'),
 ('ed9460dda9486e13dcd70ef85d9a1fb89312a151','freeze','test_relative_review_keeps_absolute_evidence_paths_inside_the_run')]:
 full=subprocess.check_output(['git','rev-parse',commit],cwd=root,text=True).strip()
 source=subprocess.check_output(['git','show',full+':benchmarks/core.py'],cwd=root,text=True)
 node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name==name)
 namespace=core.__dict__.copy();exec(compile(ast.Module(body=[node],type_ignores=[]),full+':benchmarks/core.py','exec'),namespace)
 print('OLD FUNCTION:',name,'COMMIT:',full,'TEST:',test,'SYNTHETIC UNIT EVIDENCE',flush=True)
 with patch.object(core,name,namespace[name]):result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite([ScoringTest(test)]))
 assert len(result.errors)==1 and not result.failures,result
 assert 'ValueError' in result.errors[0][1] and 'subpath' in result.errors[0][1]
 print('Expected old failure confirmed.',flush=True)
