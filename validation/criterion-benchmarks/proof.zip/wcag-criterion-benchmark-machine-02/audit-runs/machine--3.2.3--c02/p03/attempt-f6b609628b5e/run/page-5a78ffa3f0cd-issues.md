# 修正担当向けの不適合記録

この記録は検証結果です。製品コードの変更は行っていません。

予定範囲の検査完了: いいえ
結果: 未実施 55
全基準と範囲の未確認は[HTMLレポート](page-5a78ffa3f0cd-report.html)又は[JSON](page-5a78ffa3f0cd-report.json)を参照してください。
