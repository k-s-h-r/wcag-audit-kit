# 媒体の情報と代替を検証する

対象のページ・プレーヤー・全媒体・選択可能なトラック・収録済みかライブかを特定する。字幕の存在、デコードの成功、再生終了は、それぞれの観察として扱う。発話・話者・意味のある音、重要な映像情報と、その代替の内容・順序・同期を実際に比較する。

## 1. 対象とストリームを調べる

ページで使う媒体を取得できる場合は、元ファイルとハッシュを保持する。HTMLのURLと実際に選ばれたcurrentSrc・言語・音声・字幕・解説のトラックを対応付ける。別の言語又は別版の結果を流用しない。暗号化やストリーミング等でファイルを取得できない場合は、実際の再生・操作と観察の証拠を調べる。

```sh
python3 scripts/media_inventory.py --media /project/movie.webm --captions /project/english.vtt --frame-hashes --out /project/artifacts/media-source-001
```

ffprobeの全ストリーム、全映像・音声のデコード、字幕原文、原本のハッシュを保存する。`--frame-hashes`は各映像ストリームの全フレームをRGBA 8-bitへ復号してSHA-256を記録する。`media.json`の内容・字幕・閃光のreviewedフラグは、これだけでは全てfalseのままとする。

## 2. 実際のプレーヤーを操作する

字幕・解説・手話等を利用者の操作で選択し、必要な区間を再生する。検査者が直接textTracks.mode等を書き換えた結果を、利用者がその機能を使えた証拠にはしない。

HTML videoのキャプションと表示の補助には`caption_player_probe.py`を使える。実際のボタンへ合わせる。

```json
{
  "case_id":"実際のcase_id",
  "url":"http://127.0.0.1:4317/media-captions/good.html",
  "media":{"selector":"#clip"},
  "prepare_actions":[{"type":"click","selector":"#captions"}],
  "play_action":{"type":"click","selector":"#play"},
  "screenshot_times":[1.2,2.5,5.7],
  "max_seconds":15
}
```

```sh
python3 scripts/caption_player_probe.py --request /project/player-request.json --out /project/artifacts/player-001
```

click・press・wait_forで実際のUIを使う。selector又はroleとname、必要ならframeを指定する。auth_stateの相対パスは依頼ファイルの場所から解決する。各操作後のトラック・再生時刻、cue、実画面、フレームのコールバック、実際に再生された範囲、フレーム欠落等を記録する。

画面取得中も動画は進むため、要求した時刻と画像取得前後の時刻を保存する。イベントの上限超過はtruncatedとdroppedに残す。コールバック数、HTMLMediaElement.played、endedだけで、検査者が全フレーム又は音を確認したことにはしない。max_secondsで終了しなかった場合はpartialとなる。ライブの確認は、実際の配信で観察窓を決め、録画と区別する。

## 3. 全区間の情報を実際に比較する

基準ごとに必要な情報と採用する達成方法を読む。例えば1.2.2では、発話と話者、意味のある非言語音がキャプションで得られ、同期し、映像の重要な情報を妨げていないか確かめる。1.2.3の選択可能な代替と、1.2.5で必要な音声解説は区別する。媒体の文字による代替・その表示上の説明等の例外も確認する。

字幕原文、音声認識、生成時の台本は照合の補助にできる。音声認識は言語・話者・固有名詞・音質等に合う方法を調べ、既知の肯定例と否定例で確かめる。認識結果の時刻が発話の始点・終点や単語の時刻を意味するかも調べる。必要な効果音等の情報を、対話の文字起こしだけで確認済みにしない。

現在の環境では、音声をこのAIへ渡す入力が非対応だった。PocketSphinxとWhisper tiny.enは既知の合成音声の重要語を誤認識した。Whisper base.enは2つの短い発話を再現したが、デジタル無音から存在しない語も出力した。認識区間と生成音声の配置区間は異なり、実発話の境界は測定していない。その結果を音声の正解とし、字幕を自動的に不適合にする方法は採用していない。[方法の確認結果](https://github.com/k-s-h-r/wcag-audit-kit/blob/adf459777fa43ea0898a95e43edf5dbdde0684b7/validation/media/README.md)と[音声認識の校正](https://github.com/k-s-h-r/wcag-audit-kit/blob/adf459777fa43ea0898a95e43edf5dbdde0684b7/validation/media/asr/README.md)を参照する。内容の判定には、聴取又は校正された適切な別手段を準備し、用意できなければ不足する内容の比較をcant_tellに残す。

手話の全内容を比較する場合も、対象の手話言語・表情・動作の意味を判断できる手段が必要。映像があること、手が動くことだけで1.2.6の対応を確認済みにしない。

## 4. 比較区間を記録する

1.2.1〜1.2.9では、全対象を確定するため各targetの`media_review`に全長又はライブの観察窓、比較対象、区間別の事実・期待結果・証拠を残す。[書式](../assets/media-review.example.json)と[記録の取り決め](recording.md)を参照する。

比較できた区間はreviewed、できない区間はnot_reviewedと理由を記す。全区間と全対象が確定していない場合は、coverage_completeをfalseとし、残る観察を具体化する。特定区間の問題を確認した場合は、不適合と残る確認を併記できる。

## 閃光を調べる場合

動画だけでなく、字幕・プレーヤー・ページの重ね合わせ、アニメーションや操作時の変化を含む実際の提示を対象にする。全発生区間を連続して分析し、一般閃光・赤色閃光の明暗・色・回数・面積の条件を原典と照合する。

全フレームのハッシュの差は、そのまま閃光数ではない。復号・色変換・HDR・アルファ・圧縮による差、表示時の合成等の条件もある。数秒ごとの静止画や肉眼の印象だけで閾値内とはしない。[G15](https://www.w3.org/WAI/WCAG22/Techniques/general/G15)は、単純な低頻度や小領域にはG19・G176、その他は全要因を時間的に連続して扱う道具を案内している。適切な解析方法を確かめられなければ、その分析を未確認として残す。
