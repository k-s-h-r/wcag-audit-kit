from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import json
from pathlib import Path
import shutil
import threading
from playwright.sync_api import sync_playwright

root=Path.cwd()
directory=Path(__file__).parent
public=directory/'public'
shutil.copytree(root/'benchmarks/cases/2.1.2/public',public)
source=(root/'skills/wcag-page/scripts/page_explorer.js').read_text()
fixture='''<!doctype html><html><meta charset=utf-8><body><main id=site>
<button id=launch>Open</button><div id=marker hidden>Another state</div>
<div id=outer role=dialog aria-modal=true style="margin-top:160px" hidden>
<input id=field><button id=openchild>Open child</button><button id=closeparent>Close parent</button>
<div id=child role=dialog aria-modal=true hidden><input id=childfield></div></div>
<script>
const setMarker=()=>{marker.hidden=false;};
launch.onclick=()=>{outer.hidden=false;field.focus();};
openchild.onclick=()=>{child.hidden=false;childfield.focus();};
closeparent.onclick=()=>{outer.hidden=true;launch.focus();};
VARIANT
</script></main></body></html>'''
variants={
 'clean':'',
 'document-click':'document.addEventListener("click",e=>{if(e.target===field)setMarker();});',
 'ancestor-property-pointerout':'site.onpointerout=e=>{if(e.target===launch)setMarker();};',
 'ancestor-property-mouseout':'site.onmouseout=e=>{if(e.target===launch)setMarker();};',
 'launcher-pointerleave':'launch.addEventListener("pointerleave",setMarker);',
}
for name,addition in variants.items():
 (public/(name+'.html')).write_text(fixture.replace('VARIANT',addition))

class Handler(SimpleHTTPRequestHandler):
 def log_message(self,*args): pass

server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=public))
thread=threading.Thread(target=server.serve_forever,daemon=True)
thread.start()
base=f'http://127.0.0.1:{server.server_port}'
out={}
try:
 with sync_playwright() as pw:
  browser=pw.chromium.launch(executable_path='/usr/bin/chromium')
  for name in (*variants,'p07','p08'):
   ctx=browser.new_context(viewport={'width':1280,'height':900})
   ctx.add_init_script(source)
   pg=ctx.new_page()
   pg.goto(base+'/'+name+'.html')
   pg.click('#launch')
   observation=pg.evaluate('()=>window.__wcagNestedParentInput()')
   if name in variants:
    initial=pg.evaluate('()=>!marker.hidden')
    pg.click('#field')
    new=pg.evaluate('()=>!marker.hidden')
    out[name]={'hint':observation,'marker':[initial,new],'focus':pg.evaluate('()=>document.activeElement.id')}
   else:
    pg.click('#inner-opener')
    before=pg.evaluate('()=>window.__wcagDialogFocus()')
    pg.keyboard.press('Escape')
    after=pg.evaluate('()=>window.__wcagDialogFocus()')
    out[name]={'hint':observation,'before':before,'after':after}
   print(name,out[name],flush=True)
   ctx.close()
  browser.close()
finally:
 server.shutdown()
 server.server_close()
(directory/'browser-observed.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
