"""Replay scheduling with frozen route observations. No browser actions are executed."""
from collections import Counter
import json
from pathlib import Path

import page_explorer

EVIDENCE = Path('/workspace/wcag-audit-work/evidence/t038/run-007-updated/pages')
ENVIRONMENTS = [{'id': 'desktop', 'viewport': {'width':1280, 'height':900}},
                {'id': 'narrow', 'viewport': {'width':320, 'height':900}}]
ESCAPE = {'type':'press', 'selector':'body', 'key':'Escape'}
TAB = {'type':'press', 'selector':'body', 'key':'Tab'}


def identity(environment, route):
    return json.dumps([environment, route], sort_keys=True)


def load(path):
    return json.loads(path.read_bytes())


def simulate(work, limit, deferred_selector):
    graph = load(work / 'exploration.json')
    recorded = {identity(edge['environment'], edge['route']): edge for edge in graph['edges']}
    envs = {item['id']:item for item in ENVIRONMENTS}
    value = {'queue':[{'environment':env,'route':[],'initial_input':True} for env in envs], 'remaining':[]}
    queued = {identity(item['environment'], item['route']) for item in value['queue']}
    done = set(queued)
    captured = {}
    seen = {}
    counts = Counter()
    report = [{'environment':edge['environment'], 'route':edge['route']} for edge in graph['edges'][:2]]
    nodes = {(node['environment'], node['fingerprint']):node for node in graph['nodes']}

    for env in envs:
        node, = (node for node in graph['nodes'] if not node['route'] and node['environment']==env)
        captured[identity(env, [])] = node
        seen[env,node['fingerprint']] = node
        page_explorer.queue_state_actions(value, node, load(work/node['evidence_dir']/'state.json'),
                                          envs[env], queued, done, quick=True, max_depth=3)
    while value['queue'] and len(report)<limit:
        if value['queue'][0]['route'] and value['queue'][0].get('dialog_focus') not in {'escape','tab'}:
            index = min(range(len(value['queue'])), key=lambda i: (
                bool(value['queue'][i]['route']), counts[value['queue'][i]['environment']],
                not value['queue'][i].get('keyboard_followup'), not value['queue'][i].get('newly_available'),
                len(value['queue'][i]['route'])))
            value['queue'].insert(0,value['queue'].pop(index))
        job=value['queue'][0]; env=job['environment']; route=job['route']
        report.append({'environment':env,'route':route})
        if not route:
            value['queue'].pop(0)
            continue
        key=identity(env,route); done.add(key); counts[env]+=1
        edge=recorded[key]
        path=work/edge['evidence_dir']; data=load(path/'state.json')
        record=load(path/'dialog-focus.json') if (path/'dialog-focus.json').is_file() else {}
        if record.get('phase')!='tab' and record.get('status')=='closed':
            follow=route+[TAB]; follow_id=identity(env,follow)
            if len(follow)<=3 and follow_id not in queued and follow_id not in done:
                value['queue'].insert(1,{'environment':env,'route':follow,'dialog_focus':'tab'})
                queued.add(follow_id)
        state_key=(env,edge['fingerprint']); parent=captured.get(identity(env,route[:-1]))
        if state_key not in seen:
            node=nodes[state_key]; seen[state_key]=node
            page_explorer.queue_state_actions(value,node,data,envs[env],queued,done,quick=True,max_depth=3,parent=parent)
            if deferred_selector and len(route)==1 and route[0]['type']=='click' and data['modal']=='#outer':
                target = route + [{'type':'click','selector':deferred_selector}]
                deferred=next((item for item in value['queue'] if item['environment']==env and item['route']==target),None)
                if deferred and deferred.get('newly_available'):
                    deferred.pop('newly_available')
            if deferred_selector and len(route)==2 and all(action['type']=='click' for action in route):
                # Frozen fixtures' candidate pair had been verified separately.
                before=record.get('before_close',{}).get('modals',[])
                after=record.get('after_close',{}).get('modals',[])
                if len(before)==1 and len(after)==2 and after[:1]==before:
                    index=next(i for i,item in enumerate(value['queue']) if item['environment']==env and item['route']==route+[ESCAPE])
                    value['queue'].insert(1,value['queue'].pop(index))
        captured[key]=seen[state_key]
        value['queue'].pop(0)
    return report, value['queue']


results={}
for name in ('045','046'):
    work=EVIDENCE/name/'page/work'
    graph=load(work/'exploration.json')
    actual=[{'environment':edge['environment'],'route':edge['route']} for edge in graph['edges']]
    replay,_=simulate(work,64,None)
    assert replay==actual
    results[name]={}
    for selector in ('#outer','#outer-name'):
        projected,queue=simulate(work,24,selector)
        kept_children=[i+1 for i,edge in enumerate(projected) if len(edge['route'])==2 and edge['route'][1].get('key')=='Enter' and edge['route'][1]['selector']=='#inner-opener']
        kept_parent=[i+1 for i,edge in enumerate(projected) if len(edge['route'])>=2 and edge['route'][1]['selector']=='#outer-close']
        escape_steps=[i+1 for i,edge in enumerate(projected) if len(edge['route'])==3 and edge['route'][-1]==ESCAPE]
        dropped=[(i+1,edge) for i,edge in enumerate(actual[:24]) if edge not in projected]
        print(name,selector,escape_steps,'children',kept_children,'parent',kept_parent,'later',[(i,e['environment']) for i,e in dropped])
        assert escape_steps==[14,16] and kept_children==[17,18] and kept_parent==list(range(19,25))
        assert len(dropped)==2 and all(edge['route'][1]['selector']==selector for _,edge in dropped)
        assert all(any(item['route']==edge['route'] and item['environment']==edge['environment'] for item in queue) for _,edge in dropped)
        results[name][selector]={'nested_escape_steps':escape_steps,'child_enter_steps':kept_children,'parent_close_steps':kept_parent,
                                'deferred_steps':dropped,'projected_first_24':projected}
path=Path(__file__).with_suffix('.json')
path.write_text(json.dumps({'projection_only':True,'cases':results},ensure_ascii=False,indent=2)+'\n')
print(path)
