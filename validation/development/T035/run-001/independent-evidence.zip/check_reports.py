from copy import deepcopy
import json
from pathlib import Path
import re
from tempfile import TemporaryDirectory
import shutil
from openpyxl import load_workbook
from benchmarks import core
from benchmarks.url_only_machine_score import matching_target_spacing,initial_transitions,score_page
from target_spacing import CHECKPOINT,EVIDENCE_FILE

base=Path('/workspace/wcag-audit-work/evidence/t035-target-spacing/first-product')
def load(path):
    return json.loads(path.read_text())
pages=load(base/'inventory.json')['pages']
for p in pages:
    location=base/'pages'/p['id']
    if not (location/'collection.json').is_file():
        continue
    folder=location/'page'
    work=folder/'work'
    report=load(folder/'data/report.json')
    graph=load(work/'exploration.json')
    checked=[r for r in report['machine_checks'] if r['checkpoint']==CHECKPOINT]
    criterion=next(r for r in report['criteria'] if r['id']=='2.5.8')
    assert criterion['status']=='unverified' and not report['audit_complete']
    assert all(c['outcome']=='not_run' for c in report['cases'] if c['criterion']=='2.5.8')
    outcomes=[(r['target'],r['status']) for r in score_page(base,p)[0]]
    print(p['page'],len(checked),outcomes,'criterion',criterion['status'])
    html=(folder/'reports/report.html').read_text()
    hrefs=re.findall(r'href="([^"]+)"',html)
    for row in checked:
        assert all((work/x).is_file() for x in [row['evidence'],*row['proof']])
        assert any((folder/'reports'/h).resolve()==(work/row['evidence']).resolve() for h in hrefs)
    book=load_workbook(folder/'reports/report.xlsx',read_only=True,data_only=True)
    xlsx=[row for row in book['機械検査'].values if CHECKPOINT in row]
    assert len(xlsx)==len(checked)
    book.close()
    if p['page']!='p03.html':
        continue
    edge=next(e for e in graph['edges'] if not e['route'] and e['environment']=='desktop')
    path=Path(edge['evidence_dir'])
    chosen=p['rows'][0]
    with TemporaryDirectory(prefix='wcag-t035-review-mutated-') as temp:
        out=Path(temp)
        copy=out/'work'
        (copy/path).mkdir(parents=True)
        for n in ('axe.json','state.json','transition.json',EVIDENCE_FILE):
            shutil.copyfile(work/path/n,copy/path/n)
        transitions=list(initial_transitions(copy,[edge]))
        def score(test_graph=graph,rows=checked):
            return list(matching_target_spacing(chosen,rows,transitions,copy,out,test_graph))
        baseline=score()
        assert len(baseline)==1 and baseline[0]['outcome']=='failed'
        candidate=copy/path/EVIDENCE_FILE
        original=candidate.read_bytes()
        mutated=load(candidate)
        mutated['items'][0]['width']=24
        core.save(candidate,mutated)
        assert not score()
        replacement=deepcopy(graph)
        next(x for x in replacement['proof'] if x['path']==(path/EVIDENCE_FILE).as_posix())['sha256']=core.file_hash(candidate)
        assert not score(replacement)
        candidate.write_bytes(original)
        forged=[dict(r,outcome='passed') for r in checked]
        assert not score(rows=forged)
        t=copy/path/'transition.json'
        changed=load(t)
        changed['native_events']=[{'kind':'browser-unexpected'}]
        core.save(t,changed)
        replacement=deepcopy(graph)
        next(x for x in replacement['proof'] if x['path']==(path/'transition.json').as_posix())['sha256']=core.file_hash(t)
        assert not score(replacement)
    print('p03 exact actual evidence, and independent scorer tamper checks passed')
