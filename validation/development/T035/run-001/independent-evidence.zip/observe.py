import asyncio
from copy import deepcopy
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import sys
from threading import Thread

from playwright.async_api import async_playwright

repo=Path.cwd()
sys.path.insert(0,str(repo/'skills/wcag-audit-kit/scripts'))
from page_explorer import SCRIPT
import target_spacing

out=Path(__file__).resolve().parent
public=out/'public'
public.mkdir(exist_ok=True)
for n in ('p03','p04'):
    path=repo/'benchmarks/cases/2.5.8/public'/f'{n}.html'
    (public/path.name).write_bytes(path.read_bytes())

def button(name, width, height, extra=''):
    return (f'<button id="{name}" style="box-sizing:border-box;'
            f'width:{width}px;height:{height}px;padding:0"{extra}>{name[0].upper()}</button>')

def fixture(name,left=(16,16),right=(16,16),gap='8px',rootcss='',css='',tail='',extras=('', '')):
    html=f'''<!doctype html><html lang="en"><meta charset="utf-8"><title>Spacing control</title>
<style>body{{margin:32px;font:18px/1.6 sans-serif}}#pair{{display:flex;gap:{gap};{rootcss}}}{css}</style>
<main><h1>Spacing control</h1><div id="pair">{button('alpha',*left,extras[0])}{button('beta',*right,extras[1])}</div>{tail}</main>'''
    (public/f'{name}.html').write_text(html)
fixture('exact-size',(24,24),(24,24),gap='0')
fixture('center-exact')
fixture('vertical-center-exact',rootcss='flex-direction:column;')
fixture('center-below',gap='7.99px')
fixture('rect-tangent',right=(30,16),gap='4px')
fixture('rect-overlap',right=(30,16),gap='3.99px')
fixture('ancestor-overflow',(24,24),(24,24),gap='0',
        rootcss='width:47.5px;overflow:hidden;',
        css='button{flex:none}')
fixture('subgrid-overlay',(24,24),(24,24),gap='0',
        rootcss='position:relative;',css='#cover{position:absolute;left:4px;top:4px;width:3px;height:4px;opacity:0;}',
        tail='',extras=('', ''))
p=public/'subgrid-overlay.html'
p.write_text(p.read_text().replace('</div></main>', '<div id="cover"></div></div></main>'))
fixture('pseudo-extension',gap='2px',
        css='button{position:relative;}button::before{content:"";position:absolute;top:-4px;bottom:-4px;}'
            '#alpha::before{left:-8px;right:0;}#beta::before{left:0;right:-8px;}')
fixture('label-association',gap='2px',tail='<label for="alpha">Expanded accessible action</label>')
fixture('equivalent-popover',left=(16,24),right=(28,24),gap='2px',
        tail='<p id="popup" popover>Same action</p>',extras=(' popovertarget="popup"', ' popovertarget="popup"'))
fixture('decorative-native-overlay',(24,24),(24,24),gap='0',
        css='main{position:relative;}main::after{content:"";position:absolute;left:5px;bottom:5px;width:3px;height:3px;}')

fixture('transparent-link-gap',rootcss='position:relative;')
p=public/'transparent-link-gap.html'
p.write_text(p.read_text().replace('</div></main>', '<a id="link" href="#destination" aria-disabled="true" style="position:absolute;left:18px;top:0;width:4px;height:16px;opacity:0">Link</a></div></main>'))

class Handler(SimpleHTTPRequestHandler):
    def log_message(self,*_):
        pass

async def main(origin):
    case_data={}
    async with async_playwright() as pw:
        browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--disable-dev-shm-usage'])
        browser_context=await browser.new_context(viewport={'width':1280,'height':900})
        await browser_context.add_init_script(SCRIPT)
        page=await browser_context.new_page()
        for path in sorted(public.glob('*.html')):
            await page.goto(f'{origin}/{path.name}')
            await page.evaluate('() => window.__wcagWaitForUpdates()')
            state=await page.evaluate('() => window.__wcagExplore()')
            record=await target_spacing.observe(page,state,'desktop')
            capture={'environment':'desktop','key':'independent-test','url':page.url,'final_url':page.url}
            rows=list(target_spacing.report_rows(record,state,capture,'independent-target-spacing.json','state.json')) if record else []
            data={'record':record,'rows':rows}
            if record:
                tampered=deepcopy(record)
                tampered['items'][0]['width']+=2
                assert not list(target_spacing.report_rows(tampered,state,capture,'modified.json','state.json'))
                tampered=deepcopy(record)
                tampered['items'][0]['hit_points'][0][0]+=1
                assert not list(target_spacing.report_rows(tampered,state,capture,'modified.json','state.json'))
                data['tampered_width_and_hit_samples_rejected']=True
            if path.stem in {'ancestor-overflow','subgrid-overlay','pseudo-extension','decorative-native-overlay','transparent-link-gap'}:
                data['counter_sample']=await page.evaluate("""mode => {
                    const a=document.querySelector('#alpha').getBoundingClientRect();
                    const b=document.querySelector('#beta').getBoundingClientRect();
                    if(mode==='ancestor-overflow')return document.elementFromPoint(b.right-.125,b.top+12)?.id;
                    if(mode==='transparent-link-gap')return document.elementFromPoint(a.right+3,a.top+8)?.id;
                    if(mode==='subgrid-overlay')return document.elementFromPoint(a.left+5,a.top+5)?.id;
                    if(mode==='decorative-native-overlay')return document.elementFromPoint(a.left+6,a.bottom-6)?.id;
                    return [document.elementFromPoint(a.left-3,a.top+8)?.id,document.elementFromPoint(b.right+3,b.top+8)?.id];
                }""",path.stem)
            case_data[path.stem]=data
            measured=[(r['target'],r['outcome'],r['observed']) for r in rows]
            print(path.stem,measured if measured else 'hold',data.get('counter_sample'),flush=True)
        await browser.close()
    (out/'browser-review.json').write_text(json.dumps(case_data,ensure_ascii=False,indent=2))

server=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,directory=public))
thread=Thread(target=server.serve_forever,daemon=True)
thread.start()
try:
    asyncio.run(main(f'http://127.0.0.1:{server.server_port}'))
finally:
    server.shutdown()
    server.server_close()
