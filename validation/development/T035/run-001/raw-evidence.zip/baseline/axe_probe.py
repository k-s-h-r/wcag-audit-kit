from pathlib import Path
import json
import shutil
import sys

from benchmarks import runner
from playwright.sync_api import Error, sync_playwright

repo = Path.cwd()
out = Path(__file__).resolve().parent
public = out / 'public'
shutil.copytree(repo/'benchmarks/cases/2.5.8/public', public, dirs_exist_ok=True)
source = (public/'p03.html').read_text()
(public/'spacing-exact.html').write_text(source.replace('gap:2px','gap:8px'))
(public/'spacing-under.html').write_text(source.replace('gap:2px','gap:7.984375px'))
(public/'hit-cover.html').write_text(source.replace('display:flex;gap:2px','display:flex;gap:2px;position:relative').replace('</div></main>', '<span id="cover" style="position:absolute;left:2px;top:2px;width:12px;height:12px;z-index:2;background:white"></span></div></main>'))
(public/'ua-default.html').write_text(source.replace('button{padding:.4rem}','').replace('button,input,select,textarea{font:inherit}','').replace(' style="box-sizing:border-box;padding:0;width:16px;height:16px"',''))
server = runner.server(public)
axe = repo/'skills/wcag-audit-kit/vendor/axe.min.js'
pages = ['p01.html','p02.html','p03.html','p04.html','p05.html','spacing-exact.html','spacing-under.html','hit-cover.html','ua-default.html']
snapshots = {}
groups = ('passes','violations','incomplete','inapplicable')

def geometry(page):
    return page.evaluate('''() => {
        const owner = (x,y) => {
            const element = document.elementFromPoint(x,y);
            return element ? {id:element.id,tag:element.localName,control:element.closest('button,a')?.id ?? null} : null;
        };
        const targets = [...document.querySelectorAll('main button, main a')];
        const rows = targets.map((el,index) => {
            const {x,y,width,height}=el.getBoundingClientRect();
            const cx=x+width/2,cy=y+height/2;
            const points=[[cx,cy],[x+.25,cy],[x+width-.25,cy],[cx,y+.25],[cx,y+height-.25],
                [x-.25,cy],[x+width+.25,cy],[cx,y-.25],[cx,y+height+.25]];
            const css=getComputedStyle(el);
            return {name:el.id || `${el.localName}-${index+1}`, tag:el.localName,label:el.textContent,
                authorStyle:el.getAttribute('style'), form:el.form?.id ?? null, parent:el.parentElement.localName,
                display:css.display,lineHeight:css.lineHeight,pointerEvents:css.pointerEvents,
                x,y,width,height,center:[cx,cy],rects:el.getClientRects().length,
                pointResults:points.map(([x,y]) => ({x,y,owner:owner(x,y)}))};
        });
        const gaps=rows.length===2 ? {
            visual:rows[1].x-(rows[0].x+rows[0].width), distance:Math.hypot(rows[1].center[0]-rows[0].center[0],rows[1].center[1]-rows[0].center[1]),
            midpoint:owner((rows[1].x+rows[0].x+rows[0].width)/2,rows[0].center[1])} : null;
        return {targets:rows, gap:gaps};
    }''')

try:
    with sync_playwright() as playwright:
        with playwright.chromium.launch(executable_path=shutil.which('chromium')) as browser:
            for basis, width in [('desktop',1280),('narrow',320)]:
                with browser.new_context(viewport={'width':width,'height':900}) as context:
                    page = context.new_page()
                    for name in pages:
                        url=f'http://127.0.0.1:{server.server_port}/{name}'
                        page.goto(url)
                        page.add_script_tag(path=axe)
                        metadata=page.evaluate("() => ({version:axe.version, rules:axe.getRules().filter(r=>r.ruleId==='target-size')})")
                        default = page.evaluate('() => axe.run({resultTypes:["passes","violations","incomplete","inapplicable"]})')
                        try:
                            only = page.evaluate("() => axe.run({runOnly:{type:'rule',values:['target-size']},rules:{'target-size':{enabled:true}},resultTypes:['passes','violations','incomplete','inapplicable']})")
                        except Error as error:
                            only = {'error':str(error)}
                        selected = {g:[r for r in default[g] if r['id']=='target-size'] for g in groups}
                        rects = geometry(page)
                        rows = {'url':url,'browser':browser.version,'axe':metadata,'axeDefault':selected,'axeOnly':only,'geometry':rects}
                        if name in {'p03.html','hit-cover.html'}:
                            page.evaluate('''() => {
                                window.targetEvidence=[];
                                document.addEventListener('click',e=>window.targetEvidence.push({id:e.target.id,tag:e.target.localName,trust:e.isTrusted,x:e.clientX,y:e.clientY}),{capture:true});
                            }''')
                            for target in rects['targets']:
                                for point in target['pointResults'][:5]:
                                    page.mouse.click(point['x'],point['y'])
                            rows['clicks']=page.evaluate('() => window.targetEvidence')
                        snapshots[f'{basis}/{name}']=rows
                        details={mode:[(r['id'],[n['target'] for n in r['nodes']]) for r in only.get(mode,[])] for mode in groups}
                        print(basis, name, metadata['version'], 'default', [k for k,v in selected.items() if v], 'explicit', details or only, flush=True)
finally:
    server.shutdown()
    server.server_close()
(out/'probe.json').write_text(json.dumps(snapshots,ensure_ascii=False,indent=2)+'\n')
