const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');
const { chromium } = require('playwright');

const root = process.argv[2];
const slug = process.argv[3];
const dest = path.join(root, slug);
fs.mkdirSync(dest, { recursive: true });
const logPath = path.join(dest, 'timeline.jsonl');
const begin = Date.now();

function log(event) {
  fs.appendFileSync(logPath, JSON.stringify({ t: new Date().toISOString(), elapsedMs: Date.now() - begin, ...event }) + '\n');
}

(async () => {
  const context = await chromium.launchPersistentContext(path.join(dest, 'profile'), {
    executablePath: '/usr/bin/chromium',
    headless: true,
    viewport: { width: 1280, height: 900 },
    locale: 'ja-JP',
    args: ['--disable-background-networking', '--force-renderer-accessibility']
  });
  const page = context.pages()[0];
  const target = await context.newCDPSession(page);
  await target.send('Accessibility.enable');
  await page.exposeFunction('recordDeliveredKey', event => log({ event: 'document-event', ...event }));
  await page.addInitScript(() => {
    document.addEventListener('keydown', event => {
      window.recordDeliveredKey({
        key: event.key,
        code: event.code,
        trusted: event.isTrusted,
        shift: event.shiftKey,
        targetTag: event.target.tagName,
        targetId: event.target.id,
        targetText: event.target.tagName === 'BODY' ? '' : event.target.innerText?.trim().slice(0, 100),
        targetLabel: event.target.getAttribute('aria-label')
      });
    }, true);
  });
  await page.goto('http://127.0.0.1:40129/' + slug + '/', { waitUntil: 'load' });
  log({ event: 'navigation', url: page.url(), chromiumExecutable: '/usr/bin/chromium', viewport: '1280x900', locale: 'ja-JP', inputMethod: 'Playwright keyboard.press via Chromium' });
  let step = 0;
  async function inspect(reason) {
    await page.waitForTimeout(120);
    const basename = String(step).padStart(2, '0') + '-' + reason.replace(/[^a-zA-Z0-9-]+/g, '-');
    const body = await page.locator('body').innerText();
    const aria = await page.locator('body').ariaSnapshot();
    const focus = await page.evaluate(() => {
      const active = document.activeElement;
      const attrs = Object.fromEntries(Array.from(active.attributes));
      const rect = active.getBoundingClientRect();
      const modal = Array.from(document.querySelectorAll('dialog,[role=dialog]')).filter(e => e.getClientRects().length > 0);
      const messages = Array.from(document.querySelectorAll('[aria-live],[role=alert],[role=status]')).filter(e => e.getClientRects().length > 0);
      return {
        active: { tag: active.tagName, attrs, text: active.tagName === 'BODY' ? '' : active.innerText?.trim().slice(0, 250), rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height } },
        modal: modal.map(e => ({ id: e.id, open: e.getAttribute('open'), role: e.getAttribute('role'), modal: e.getAttribute('aria-modal'), label: e.getAttribute('aria-labelledby') || e.getAttribute('aria-label') })),
        messages: messages.map(e => ({ id: e.id, role: e.getAttribute('role'), live: e.getAttribute('aria-live'), text: e.innerText?.trim() })),
        scroll: {x: window.scrollX, y: window.scrollY}
      };
    });
    const axTree = await target.send('Accessibility.getFullAXTree');
    fs.writeFileSync(path.join(dest, basename + '.dom.txt'), body);
    fs.writeFileSync(path.join(dest, basename + '.aria.yaml'), aria);
    fs.writeFileSync(path.join(dest, basename + '.chromium-ax.json'), JSON.stringify(axTree, null, 2));
    await page.screenshot({ path: path.join(dest, basename + '.png'), animations: 'disabled' });
    log({ event: 'state', step, reason, basename, focus });
    console.log(JSON.stringify({ step, reason, focus, body: body.slice(0, 5500), aria: aria.slice(0, 7000) }));
  }
  await inspect('initial');
  const rl = readline.createInterface({input: process.stdin, output: process.stdout});
  for await (const line of rl) {
    const [input, ...rest] = line.trim().split(/\s+/);
    if (input === 'finish') {
      log({ event: 'stopped', note: rest.join(' ') });
      break;
    }
    if (input === 'observe') {
      step += 1;
      await inspect(rest.join('-') || 'followup');
      continue;
    }
    if (!input) continue;
    step += 1;
    log({ event: 'requested-key', step, key: input });
    await page.keyboard.press(input);
    await inspect(input);
  }
  await context.close();
})().catch(error => {
  console.error(error);
  log({ event: 'error', message: error.message });
  process.exitCode = 1;
});
