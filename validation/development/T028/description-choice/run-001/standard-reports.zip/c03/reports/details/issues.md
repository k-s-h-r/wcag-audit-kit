# 修正担当向けの不適合記録

この記録は検証結果です。製品コードの変更は行っていません。

WCAG 2.2 AA の結論　不適合
予定範囲の検査完了: いいえ
結果: 未実施 109、不適合 1
全基準と範囲の未確認は[HTMLレポート](../report.html)又は[JSON](../../data/report.json)を参照してください。

## 1.2.5 音声解説 (収録済)

対象: http://127.0.0.1:45397/p03.html / after-select / desktop

再現手順:

- TabとEnterで音声解説を選択する。
- Shift+Tabで再生ボタンに戻り、Spaceで最初から終端まで再生する。
- 配信された動画とブラウザーで再生した音声を、受付コードの表示と照合する。

対象要素: #subject / 1.2.5-01 / 受付コード7291
期待結果: 音声解説を選んで再生した音声から、画面の受付コード7291が分かる。
観察結果: 音声解説の選択表示に変わった後も元動画が終端まで再生され、画面の受付コード7291は再生音声に含まれなかった。
証拠: evidence/attached/b8e4ee18399b--after-select--desktop--1.2.5/bfaa8b5a-keyboard.json, evidence/attached/b8e4ee18399b--after-select--desktop--1.2.5/e78d5e2a-observation.json, evidence/attached/b8e4ee18399b--after-select--desktop--1.2.5/fea5d101-playing-03.0.png, evidence/attached/b8e4ee18399b--after-select--desktop--1.2.5/987711fd-played-audio.webm, evidence/attached/b8e4ee18399b--after-select--desktop--1.2.5/d5c90fab-corroboration.json, evidence/attached/b8e4ee18399b--after-select--desktop--1.2.5/73a33b20-key-dispatch.json

原典: https://www.w3.org/TR/2024/REC-WCAG22-20241212/#audio-description-prerecorded
このcaseの未確認: 選択した受付コード以外の映像や非言語音の情報と、別の再生環境での結果は未確認。
