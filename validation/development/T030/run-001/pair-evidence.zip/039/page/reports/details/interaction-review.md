# 画面・操作の調査と残る確認

調査状態: not_recorded
画像の選択: initial
実SRの選択: off
