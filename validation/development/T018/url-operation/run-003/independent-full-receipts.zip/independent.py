from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(sys.argv[1])
OPENER = '#subject #opener'
INNER = '#subject #inner'
PANEL = '#subject #panel'
ROUTES = {
    (): 'initial', ('click',): 'click', ('click', 'click'): 'click_close',
    ('Enter',): 'Enter', ('Space',): 'Space', ('Enter', 'Tab'): 'tab',
    ('Enter', 'Tab', 'Shift+Tab'): 'return',
    ('Enter', 'Tab', 'Shift+Tab', 'Enter'): 'close',
}

def load(path):
    return json.loads(path.read_bytes())


def on_path(route):
    if any(step['selector'] not in (OPENER, 'body') for step in route):
        return None
    return ROUTES.get(tuple(step.get('key', step['type']) for step in route))


def main():
    comparison = {}
    known = ('one', 'two')
    for profile in (sys.argv[2:] or ('quick', 'full')):
        phases = comparison[profile] = {}
        for name in known:
            location = ROOT / profile / name
            audit = location / 'page'
            work = audit / 'work'
            graph = load(work/'exploration.json')
            initial_line, *_ = (location/'initial.log').read_text().splitlines()
            explore_line, *_ = (location/'explore.log').read_text().splitlines()
            initial_args = json.loads(initial_line)
            explore_args = json.loads(explore_line)
            assert initial_args[2] == 'page-audit' and len(initial_args) == 14, initial_args
            assert explore_args[:7] == initial_args[:7]
            assert initial_args[7:] == ['--level', 'AA', '--mode', 'machine', '--screenshots', 'initial', '--initial-only']
            assert explore_args[7:] == (['--resume', '--quick-explore'] if profile == 'quick' else
                ['--resume', '--explore', '--max-depth', '4', '--max-steps', '48', '--max-states', '16'])
            assert not graph['running'] and not graph['deferred']
            report = load(audit/'data/report.json')
            criterion = next(c for c in report['criteria'] if c['id'] == '2.1.1')
            scopes = phases[name] = dict(step_count=graph['steps'], pending=len(graph['queue']),
                                         limits=graph['limits'], audit_complete=report['audit_complete'],
                                         criterion=criterion['status'], viewports={})
            assert not scopes['audit_complete'] and criterion['status'] == 'unverified'
            proof = {p['path']: p['sha256'] for p in graph['proof']}
            def raw(relative):
                data = (work/relative).read_bytes()
                assert sha256(data).hexdigest() == proof[relative], relative
                return data
            for env in ('desktop', 'narrow'):
                outcomes = scopes['viewports'][env] = {}
                initial, = [node for node in graph['nodes'] if node['environment']==env and not node['route']]
                for edge in graph['edges']:
                    if edge['environment'] != env:
                        continue
                    route = edge['route']
                    action = on_path(route)
                    if action is None or (action == 'initial' and edge['evidence_dir']!=initial['evidence_dir']):
                        continue
                    assert action not in outcomes
                    base = edge['evidence_dir']
                    transition = json.loads(raw(base+'/transition.json'))
                    assert transition['environment'] == env and transition['route'] == route
                    if transition['error'] or transition['blocked_requests'] or transition['native_events']:
                        outcomes[action] = dict(error=transition['error'])
                        continue
                    assert all(wait['status']=='quiet' for wait in transition['settling'])
                    state = json.loads(raw(base+'/state.json'))
                    items = {node['selector']:node for node in state['state']}
                    visible = PANEL in items
                    assert items[OPENER]['expanded'] == str(visible).lower()
                    node, = [n for n in graph['nodes'] if n['environment']==env and n['fingerprint']==edge['fingerprint']]
                    ax_route = node['evidence_dir']+'/accessibility-tree.json'
                    ax = json.loads(raw(ax_route))
                    button, = [n for n in ax['nodes'] if n.get('role',{}).get('value')=='button'
                              and n.get('name',{}).get('value')=='利用時間']
                    expanded, = [p['value']['value'] for p in button['properties'] if p['name']=='expanded']
                    assert expanded == visible
                    snapshot = dict(visible=visible, dom_expanded=items[OPENER]['expanded'], ax_expanded=expanded,
                                    focus=state.get('deep_focus') or state['focus']['selector'],
                                    receipts=[base+'/transition.json',base+'/state.json',ax_route,base+'/input-events.json'])
                    if action=='initial':
                        snapshot['png_sha256']=sha256(raw(base+'/page.png')).hexdigest()
                    log = json.loads(raw(base+'/input-events.json'))
                    assert not log['truncated']
                    events=log['events']
                    relevant = [(i,event) for i,event in enumerate(events) if event['target'] and event['target']['id'] in ('opener','inner')]
                    trusted = dict(isTrusted=True,is_main_frame=True)
                    real_clicks = [(i,event) for i,event in relevant if event['type']=='click' and event['pointerType']=='mouse']
                    assert len(real_clicks)==sum(step['type']=='click' for step in route)
                    assert all(all(evt[k] is v for k,v in trusted.items()) for _,evt in real_clicks)
                    if action in ('Enter','Space','close'):
                        index=transition['key_effect']['event_index']
                        event=events[index]
                        key='[character]' if action=='Space' else 'Enter'
                        assert (event['type'],event['key'],event['target']['id'],event['expectedTargetMatched'])==('keydown',key,'opener',True)
                        assert all(event[k] is v for k,v in trusted.items()) and not any(event['modifiers'].values())
                        keyboard_clicks=[(i,evt) for i,evt in relevant if i>index and evt['type']=='click' and evt['pointerType']=='']
                        assert len(keyboard_clicks)==(1 if name=='one' else 0)
                        assert all(all(evt[k] is v for k,v in trusted.items()) for _,evt in keyboard_clicks)
                        assert transition['key_effect']['after']['expanded']==str(visible).lower()
                        snapshot.update(keydown_event_index=index, native_keyboard_click_indices=[i for i,_ in keyboard_clicks])
                        if action in ('Enter','Space'):
                            checks=[r['outcome'] for r in report['machine_checks'] if r['environment']==env
                                    and r['evidence']==base+'/transition.json'
                                    and r['criterion']=='2.1.1' and r['checkpoint']=='キー操作後の領域の表示とフォーカス']
                            assert checks==(['passed'] if name=='one' else ['cant_tell']), checks
                            snapshot['machine']=checks[0]
                    if action in ('tab','return','close'):
                        tab, = [(i,evt) for i,evt in relevant if evt['type']=='keydown' and evt.get('key')=='Tab'
                                and evt['target']['id']=='opener' and not evt['modifiers']['shift']]
                        assert all(tab[1][k] is v for k,v in trusted.items())
                        snapshot['tab_index']=tab[0]
                    if action in ('return','close'):
                        back, = [(i,evt) for i,evt in relevant if evt['type']=='keydown' and evt.get('key')=='Tab'
                                 and evt['target']['id']=='inner' and evt['modifiers']['shift']]
                        assert back[0]>tab[0] and all(back[1][k] is v for k,v in trusted.items())
                        snapshot['shift_tab_index']=back[0]
                    outcomes[action]=snapshot
                assert not outcomes['initial']['visible']
                assert outcomes['click']['visible']
                assert outcomes['Enter']['visible'] == (name=='one')
                if profile=='quick':
                    assert 'Space' not in outcomes
                else:
                    assert outcomes['Space']['visible'] == (name=='one')
                for route, visible, focus in [('tab',True,INNER),('return',True,OPENER),('close',False,OPENER)]:
                    if route in outcomes and 'error' not in outcomes[route]:
                        assert name=='one' and outcomes[route]['visible'] is visible and outcomes[route]['focus']==focus
                if name=='one' and profile=='quick':
                    assert outcomes['tab']['focus']==INNER
        for env in ('desktop','narrow'):
            viewports=[phases[name]['viewports'][env] for name in known]
            assert viewports[0]['initial']['png_sha256']==viewports[1]['initial']['png_sha256']
    print(json.dumps(comparison,ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
