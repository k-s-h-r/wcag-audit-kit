import argparse
from functools import partial
from http.server import ThreadingHTTPServer
from pathlib import Path
import runpy
import subprocess
from threading import Thread
from types import SimpleNamespace

parser=argparse.ArgumentParser()
parser.add_argument('source',type=Path)
parser.add_argument('profile',choices=('quick','full'))
parser.add_argument('out',type=Path)
args=parser.parse_args()
loaded=runpy.run_path(str(args.source))
collect=loaded['collect']
public=loaded['PUBLIC']

def with_longer_wall_timeout(*command, timeout, **kwargs):
    return subprocess.run(*command, timeout=900, **kwargs)

# Keep the original CLI arguments and fixed exploration bounds; serialize the
# independent reproduction and extend only the collection runner's wall limit.
collect.__globals__['subprocess']=SimpleNamespace(run=with_longer_wall_timeout, STDOUT=subprocess.STDOUT)
args.out.mkdir()
with ThreadingHTTPServer(('127.0.0.1',0),partial(loaded['QuietHTTP'],directory=str(public))) as server:
    thread=Thread(target=server.serve_forever,daemon=True)
    thread.start()
    try:
        for fixture in sorted(public.glob('*.html')):
            collect(args.out / fixture.stem, f'http://127.0.0.1:{server.server_port}/{fixture.name}',
                    loaded['PROFILES'][args.profile])
    finally:
        server.shutdown()
        thread.join()
