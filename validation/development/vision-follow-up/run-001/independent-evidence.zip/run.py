from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
from threading import Thread

repo=Path.cwd()
area=Path(__file__).parent
public=area/'public'
cli=repo/'skills/wcag-page/scripts/audit.py'
for criterion in ('2.1.2','3.2.1'):
    shutil.copytree(repo/'benchmarks/cases'/criterion/'public',public/criterion)
revision=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True).stdout.strip()
assert revision=='89fc5dcc8a3b0b48f7c9e9175ff3cd68cda87840'
checkpoint='ダイアログからのキー操作による離脱'
requests=[]

class Server(SimpleHTTPRequestHandler):
    def log_request(self,status='-',size='-'):
        requests.append(dict(method=self.command,path=self.path,status=status))
    def log_message(self,*args):
        pass

def load(path):
    return json.loads(path.read_text())

def invoke(log,args):
    line=[sys.executable,str(cli),*map(str,args)]
    with log.open('w') as sink:
        subprocess.run(line,stdout=sink,stderr=subprocess.STDOUT,timeout=300,check=True)
    if args[0]=='page-next':
        return load(log)

def rows(result):
    return [(case,row) for case in result['next_cases'] for row in case['machine_results']
            if row['checkpoint']==checkpoint]

def verify_phases(location,url):
    run=location/'page'
    cmd=['page-audit','--url',url,'--out',run]
    next_=['page-next','--run',run,'--page-exact',url]
    invoke(location/'initial.log',cmd+['--initial-only','--level','AAA','--mode','machine','--screenshots','initial'])
    first=invoke(location/'next-initial.json',next_)
    assert first['exploration']['deferred'] and first['exploration']['next']=='page-audit --resume --quick-explore'
    assert not rows(first)
    print(location.name,'initial results before exploration verified',flush=True)
    invoke(location/'explore.log',cmd+['--resume','--quick-explore'])
    last=invoke(location/'next-explored.json',next_)
    assert last['exploration']['deferred'] is False and last['audit_complete'] is False
    assert len(last['next_cases'])==5
    return run,last

def verify_traps(run,last,url,expected):
    observed=rows(last)
    assert [(e['environment'],r['outcome']) for e,r in observed]==[('desktop',expected),('narrow',expected)]
    assert [x['case_id'] for x,_ in observed]==[x['case_id'] for x in last['next_cases'][:2]]
    work=Path(last['evidence_base'])
    graph=load(work/'exploration.json')
    graph_proof={i['path']:i['sha256'] for i in graph['proof']}
    summary=[]
    for case,row in observed:
        assert case['criterion']=='2.1.2' and case['page_url']==url and case['state']!='initial'
        assert case['outcome']=='not_run' and case['assessment_data'] is None
        assert row['case_capture']==case['capture'] and row['environment']==case['environment']
        assert row['page_url']==url and row['target']=='#panel'
        assert [a['key'] for a in row['operation_route']]==['Enter','Escape']
        for p in [row['evidence'],*row['proof']]:
            assert hashlib.sha256((work/p).read_bytes()).hexdigest()==graph_proof[p]
        statefile=Path(case['evidence_dir'])/'state.json'
        assert statefile.as_posix() in row['proof']
        state=load(work/statefile)
        receipt=load(work/row['evidence'])['keyboard_trap']
        inputs=load((work/row['evidence']).with_name('input-events.json'))
        assert inputs['truncated'] is False and receipt['outcome']==expected
        start=inputs['events'][receipt['opener_event_index']]
        end=inputs['events'][receipt['escape_event_index']]
        assert (start['key'],end['key'])==('Enter','Escape') and start['documentId']==end['documentId']
        assert all(r['isTrusted'] and r['is_main_frame'] and r['expectedTargetMatched'] for r in (start,end))
        assert receipt['before']['modals']==[state['modal']]==['#panel']
        assert receipt['before']['focus']==(state.get('deep_focus') or state['focus']['selector'])
        summary.append({'case':case['case_id'],'state':case['state'],'environment':case['environment'],
                        'case_outcome':case['outcome'],'observation':row['outcome'],'route':row['operation_route'],
                        'evidence':row['evidence'],'proof':row['proof']})
    return summary

def verify_navigation(run,last,url):
    work=Path(last['evidence_base'])
    graph=load(work/'exploration.json')
    report=load(run/'data/report.json')
    criterion=next(row for row in report['criteria'] if row['id']=='3.2.1')
    assert criterion['status']=='unverified'
    assert not any(row['criterion']=='3.2.1' and row['outcome'] in {'passed','failed','inapplicable'}
                   for row in report['machine_checks'])
    assert all(row['outcome']=='not_run' for row in report['cases'] if row['criterion']=='3.2.1')
    found={}
    for p in sorted(work.rglob('keyboard-trace-stop.json')):
        stop=load(p)
        receipt=stop.get('focus_navigation')
        if not receipt: continue
        log=load(p.with_name('input-events.json'))
        types=['keydown','focus','navigation','keyup']
        records={name:log['events'][receipt[name+'_event_index']] for name in types}
        frames={record['is_main_frame'] for record in records.values()}
        assert frames=={True} and all(record['isTrusted'] and record['url']==url for record in records.values())
        assert len({record['documentId'] for record in records.values()})==1
        assert [records[name]['type'] for name in types]==['keydown','focus','navigate','keyup']
        assert records['keydown']['key']==records['keyup']['key']=='Tab'
        assert not log['truncated'] and stop['step']==1 and stop['child_frame_observed'] is False
        assert receipt['target']=={'tag':'input','id':'subject'}
        assert records['keyup']['navigationAtKeyup']=={
            'id':records['navigation']['navigationId'],'dispatchEnded':True,'canceled':False,'aborted':False}
        assert records['navigation']['focusDispatchPhase']==2 and records['navigation']['sameDocument'] is False
        block=stop['blocked_requests'][receipt['blocked_request_index']]
        assert block['url']==receipt['destination'] and block['url'].endswith('/details.html')
        assert block['resource_type']=='document' and block['is_main_frame'] and block['reason']=='navigation_out_of_scope'
        path=p.relative_to(work).as_posix()
        assert any('通信を遮断' in entry and '未確認' in entry and path in entry for entry in last['exploration']['remaining'])
        found[p.parent.name.rsplit('--',1)[-1]]={'stop_path':path,'receipt':receipt,'blocked':block}
    assert set(found)=={'desktop','narrow'}
    assert sum('別文書への移動が要求された' in entry for entry in report['exploration']['remaining'])==2
    assert not any(request['path'].endswith('/details.html') for request in requests)
    return found

def main():
    results={}
    with ThreadingHTTPServer(('127.0.0.1',0),partial(Server,directory=public)) as server:
        thread=Thread(target=server.serve_forever,daemon=True)
        thread.start()
        try:
            for page,path,expected in [('039','2.1.2/p01.html','passed'),('040','2.1.2/p02.html','failed'),
                                       ('073','3.2.1/p03.html',None)]:
                location=area/page
                location.mkdir()
                url=f'http://127.0.0.1:{server.server_port}/{path}'
                run,last=verify_phases(location,url)
                results[page]=verify_traps(run,last,url,expected) if expected else verify_navigation(run,last,url)
                (area/'summary.json').write_text(json.dumps({'revision':revision,'pages':results},
                                                           ensure_ascii=False,indent=2))
                print(page,'all evidence verified',flush=True)
        finally:
            server.shutdown()
            thread.join()
            (area/'http-requests.json').write_text(json.dumps(requests,indent=2))

if __name__=='__main__':
    main()
