"""Record visible browser state after inputs supplied during the review."""
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit

from playwright.sync_api import sync_playwright


def observe(url, evidence):
    evidence.mkdir(exist_ok=False)
    trace = []
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(executable_path='/usr/bin/chromium', headless=True)
        page = browser.new_page(viewport={'width': 1280, 'height': 900}, locale='ja-JP')
        origin = urlsplit(url).netloc
        page.route('**/*', lambda route: route.continue_() if urlsplit(route.request.url).netloc == origin else route.abort())
        page.on('request', lambda request: requests.append({'method': request.method, 'url': request.url}))
        requests = []

        def snapshot(action):
            image = evidence / f'{len(trace):02d}.png'
            page.screenshot(path=image)
            focused = page.locator(':focus')
            data = {'action': action, 'url': page.url, 'title': page.title(), 'shown': page.locator('body').inner_text(),
                    'focus': focused.inner_text() if focused.count() else None,
                    'ax': page.locator('body').aria_snapshot(), 'image': image.name}
            trace.append(data)
            (evidence / 'result.json').write_text(json.dumps({
                'browser': browser.version, 'viewport': [1280, 900], 'locale': 'ja-JP',
                'trace': trace, 'requests': requests,
            }, ensure_ascii=False, indent=2) + '\n')
            print(json.dumps(data, ensure_ascii=False), flush=True)

        page.goto(url, wait_until='load')
        snapshot({'open': url})
        for line in sys.stdin:
            action = json.loads(line)
            if action == {'finish': True}:
                break
            if 'key' in action:
                page.keyboard.press(action['key'])
            elif 'click_visible_text' in action:
                page.get_by_text(action['click_visible_text'], exact=True).click()
            else:
                raise ValueError(action)
            page.wait_for_load_state('load')
            snapshot(action)
        browser.close()


if __name__ == '__main__':
    observe(sys.argv[1], Path(sys.argv[2]))
