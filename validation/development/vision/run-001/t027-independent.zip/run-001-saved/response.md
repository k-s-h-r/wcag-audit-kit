# 工作室の見学予約のアクセシビリティ点検

キーボードで見学予約をする人は、2名以上が必要な人数選択で止まります。増員を標準のボタンに替え、確認ボタンの名前を画面の文言とそろえる変更を提案します。T022で保存した試験ページの入口から確認画面までの記録を使いました。追加操作の環境は Chromium 156.0.8078.79、1280×900です。[操作記録](../../../t022/validation/development/T022/run-001/observations.json) · [観察環境](../../../t022/validation/development/T022/run-001/environment.json)

## キーで人数を増やせない

「見学の予約を始める」をTabとEnterで開き、人数選択画面でTabを押すと「人数を増やす」に移れました。EnterとSpaceのどちらを押しても1名のままで、確認ボタンを押すと2名以上を選ぶよう案内されました。「人数を増やす」をクリックすると2名になり、次のTabとEnterで確認画面に進みました。マウスを使えない人は、この経路で必要な人数を指定できません。[Space直後](../../../t022/validation/development/T022/run-001/rb-06-increase-with-space.png) · [1名で確認した画面](../../../t022/validation/development/T022/run-001/rb-08-try-review-at-one.png) · [クリック後に進んだ確認画面](../../../t022/validation/development/T022/run-001/rb-12-review-after-pointer.png)

「人数を増やす」を `<button type="button">` に替え、既存の増員処理をボタンから起動します。同じ環境で、入口から開始、増員、確認をTabとEnterで順に実行し、人数が1名から2名になって確認画面に日付と人数が表示されるかを確かめます。増員時だけSpaceを使う試行も行います。[2.1.1の判定記録](../../t022-report/2/report/work/assessments/d9b5c09545c8--initial--desktop--2.1.1--4b76641098b9.json)

## 確認ボタンを画面の文言で指定しづらい

画面には「予約内容を確認する」と表示され、ブラウザーはアクセシブルな名前を「詳細を見る」として公開していました。見えている文言を声に出して部品を指定する人は、確認ボタンを選べない可能性があります。確認ボタンの `aria-label` を外して表示文字を名前に使い、同じ画面のツリーと表示を照合します。音声でボタンを選ぶ操作は、実際に使う音声操作ソフトでも確かめます。[確認ボタンの画面](../../../t022/validation/development/T022/run-001/rb-07-focus-review.png) · [公開された名前](../../../t022/validation/development/T022/run-001/rb-07-focus-review.ax.json) · [2.5.3の判定記録](../../t022-report/2/report/work/assessments/d9b5c09545c8--initial--desktop--2.5.3--6d3294fc7102.json)

## 元の検査票と残る確認

元のWCAG 2.2 AAの検査票は、入口、人数選択、確認の3画面を対象に不適合を記録しています。不適合は人数選択画面の初期状態、デスクトップ環境の2.1.1（キーボード）と2.5.3（ラベルを含む名前）です。元の検査票では全体の検証が未完了です。改善後の結果、実際の読み上げ・音声操作、利用者による試行は今回の記録からは確認できません。[元の検査票と不適合箇所](../../t022-report/2/report/reports/report.html#failures) · [報告JSON](../../t022-report/2/report/data/report.json)
