# 修正担当向けの不適合記録

この記録は検証結果です。製品コードの変更は行っていません。

WCAG 2.2 AAA の結論　不適合
予定範囲の検査完了: いいえ
結果: 未実施 170、不適合 2
全基準と範囲の未確認は[HTMLレポート](../report.html)又は[JSON](../../data/report.json)を参照してください。

## 3.2.1 フォーカス時

対象: http://127.0.0.1:42619/p03.html / initial / desktop

再現手順:

- 初期レポートとpage-nextで操作後の不足を確かめ、該当する初期状態と画面幅の検査票を取得する。
- 新しいChromiumの状態で同じURLを開く。初期画面で押すキーはTabを1回。
- 前後のURL、表示、フォーカス、主文書とHTTP受信を照合し、押下後1秒の範囲で判断する。

対象要素: 氏名入力欄 #subject
期待結果: フォーカスを受けただけで利用者の文脈が変わらない。
観察結果: 初期の「利用案内」でTabを1回押すと「氏名」入力欄（#subject）へフォーカスが移った。そのフォーカスイベント中にdetails.htmlが要求され、HTTP GET 200を受信して料金一覧の新しい主文書が開いた。
証拠: evidence/attached/11aac140d9ac--initial--desktop--3.2.1/f6a74517-observation.json, evidence/attached/11aac140d9ac--initial--desktop--3.2.1/a113b5cd-source-case.json, evidence/attached/11aac140d9ac--initial--desktop--3.2.1/ff0d2e32-input-events.json, evidence/attached/11aac140d9ac--initial--desktop--3.2.1/fe878be4-browser-requests.json, evidence/attached/11aac140d9ac--initial--desktop--3.2.1/9a73160f-main-frame-documents.json, evidence/attached/11aac140d9ac--initial--desktop--3.2.1/675ade5b-http-receipts.json, evidence/attached/11aac140d9ac--initial--desktop--3.2.1/961db509-before.html, evidence/attached/11aac140d9ac--initial--desktop--3.2.1/0b17c42f-after.html, evidence/attached/11aac140d9ac--initial--desktop--3.2.1/ff8e8f0a-before.png, evidence/attached/11aac140d9ac--initial--desktop--3.2.1/2f703876-after.png, evidence/11aac140d9ac--explore-b1c4d37c1fb9--desktop/keyboard-trace-stop.json

原典: https://www.w3.org/TR/2024/REC-WCAG22-20241212/#on-focus
このcaseの未確認: この画面幅の初期状態で、ほかのフォーカス先とそれに伴う変化を確認する。, ほかの状態と環境の確認、およびページ全体の検証が残る。

## 3.2.1 フォーカス時

対象: http://127.0.0.1:42619/p03.html / initial / narrow

再現手順:

- 初期レポートとpage-nextで操作後の不足を確かめ、該当する初期状態と画面幅の検査票を取得する。
- 新しいChromiumの状態で同じURLを開く。初期画面で押すキーはTabを1回。
- 前後のURL、表示、フォーカス、主文書とHTTP受信を照合し、押下後1秒の範囲で判断する。

対象要素: 氏名入力欄 #subject
期待結果: フォーカスを受けただけで利用者の文脈が変わらない。
観察結果: 初期の「利用案内」でTabを1回押すと「氏名」入力欄（#subject）へフォーカスが移った。そのフォーカスイベント中にdetails.htmlが要求され、HTTP GET 200を受信して料金一覧の新しい主文書が開いた。
証拠: evidence/attached/11aac140d9ac--initial--narrow--3.2.1/8aa6e4a0-observation.json, evidence/attached/11aac140d9ac--initial--narrow--3.2.1/598b83d1-source-case.json, evidence/attached/11aac140d9ac--initial--narrow--3.2.1/5fa3cc88-input-events.json, evidence/attached/11aac140d9ac--initial--narrow--3.2.1/ce29257d-browser-requests.json, evidence/attached/11aac140d9ac--initial--narrow--3.2.1/490bab36-main-frame-documents.json, evidence/attached/11aac140d9ac--initial--narrow--3.2.1/530efd6f-http-receipts.json, evidence/attached/11aac140d9ac--initial--narrow--3.2.1/06e83336-before.html, evidence/attached/11aac140d9ac--initial--narrow--3.2.1/6f314f8a-after.html, evidence/attached/11aac140d9ac--initial--narrow--3.2.1/f23a5730-before.png, evidence/attached/11aac140d9ac--initial--narrow--3.2.1/f5d835c3-after.png, evidence/11aac140d9ac--explore-6e98293c4b81--narrow/keyboard-trace-stop.json

原典: https://www.w3.org/TR/2024/REC-WCAG22-20241212/#on-focus
このcaseの未確認: この画面幅の初期状態で、ほかのフォーカス先とそれに伴う変化を確認する。, ほかの状態と環境の確認、およびページ全体の検証が残る。
