# 修正担当向けの不適合記録

この記録は検証結果です。製品コードの変更は行っていません。

WCAG 2.2 AA の結論　不適合
予定範囲の検査完了: いいえ
結果: 未実施 274、不適合 1
全基準と範囲の未確認は[HTMLレポート](../report.html)又は[JSON](../../data/report.json)を参照してください。

## 4.1.3 ステータスメッセージ

対象: http://127.0.0.1:36029/b7n/guests.html?date=2026-12-20 / input-error / desktop

再現手順:

- トップの「来館案内を開く」から版画室の見学日を調べる。
- 空きありと表示された12月20日を選ぶ。
- 見学人数に1を入力し、確認ボタンでSpaceを押して表示とOrca発話を照合する。
- Shift+Tabで人数へ戻り、2に修正して確認画面へ進む。

対象要素: 見学人数の入力エラー（#error）
期待結果: 確認ボタンにフォーカスを保ったまま、入力エラーの内容を支援技術で取得できる。
観察結果: 1名で確認すると「見学人数は2名以上を入力してください。」と表示され、ボタンにフォーカスが残った。公開ロールは paragraph。操作後3秒間のOrca発話は「space」。入力欄へ戻って2名に修正し、12月20日・2名の確認画面へ進んだ。
証拠: evidence/79e3e3e404eb--input-error--desktop/accessibility-tree.json, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/b029760e-request.json, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/745be49c-screen-reader.json, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/fc70126b-orca-debug.log, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/a83dde92-step-3.png, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/11323f26-step-3.json, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/3b3a7ca5-step-5.png, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/6acc9f18-step-5.json, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/ea19484d-step-13.png, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/3358f502-step-13.json, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/c4797d83-step-14.png, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/9d3831c6-step-14.json, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/cae6d82d-step-15.png, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/41b93313-step-15.json, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/c01ad4d8-step-19.png, evidence/attached/79e3e3e404eb--input-error--desktop--4.1.3/27bd0655-step-19.json

原典: https://www.w3.org/TR/2024/REC-WCAG22-20241212/#status-messages
このcaseの未確認: ほかの支援技術と全達成基準の検査が残る。
