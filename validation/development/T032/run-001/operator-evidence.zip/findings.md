# Keyboard walkthrough for a printmaking workshop visit

Both pages reached confirmation for **December 20, 2026, for two people**. Entering one person produced the same visible error and left keyboard focus on the review button. Chromium exposed the message as a paragraph on b7n and as an assertive alert on h2v.

## Pages tested

| Page | Entry | Available dates | Guest form | Confirmation |
| --- | --- | --- | --- | --- |
| b7n | `http://127.0.0.1:43933/b7n/` | `http://127.0.0.1:43933/b7n/dates.html` | `http://127.0.0.1:43933/b7n/guests.html?date=2026-12-20` | `http://127.0.0.1:43933/b7n/check.html?date=2026-12-20&people=2` |
| h2v | `http://127.0.0.1:43933/h2v/` | `http://127.0.0.1:43933/h2v/dates.html` | `http://127.0.0.1:43933/h2v/guests.html?date=2026-12-20` | `http://127.0.0.1:43933/h2v/check.html?date=2026-12-20&people=2` |

## Steps and results on both pages

1. The entry heading was `版画室を見学する`. **Tab** focused the native disclosure `来館案内を開く`. Chromium exposed it as a focusable disclosure with `expanded: false`. **Enter** opened it and changed the state to `expanded: true` with focus still on the disclosure. **Tab**, **Enter** then reached the dates page through the link `版画室の見学日を調べる`.
2. The heading was `12月の空き状況`. `12月19日 満席` was static list text. **Tab** went directly to the link `12月20日 空きあり`, the only focusable date. **Enter** opened the guest form for December 20.
3. The form heading was `見学人数を入力する`, followed by `選択した見学日は12月20日です。` **Tab** focused the blank required textbox `見学人数`. I entered **1**, then pressed **Tab** and **Enter** to activate `予約内容を確認する`. The form stayed on the same URL, displayed `見学人数は2名以上を入力してください。`, and retained the value `1`. The browser exposed the textbox as invalid and used the message as its accessible description through `aria-describedby="error"`. Focus remained on the review button.
4. **Shift+Tab** returned to the textbox. **Ctrl+A**, **2** replaced the value. At that point the earlier message was still visible and the textbox was still exposed as invalid. **Tab**, **Enter** successfully proceeded to confirmation.
5. The confirmation heading was `見学予約の確認` and the page displayed `12月20日。見学人数 2 名。` and `ここでは内容の確認まで行います。` I stopped there on each page.

The focused controls had a visible 3 px solid blue outline and stayed within the 1280 × 900 viewport during the walkthrough. The captured screenshots matched pixel for pixel between pages at all 12 checkpoints.

## b7n

The error element was a plain `p#error`. The accessibility tree exposed its text under a paragraph and used it as the textbox description. The error had no live region semantics in the captured DOM or tree.

[Dates screenshot](b7n/05-date-focus/viewport.png) · [Validation screenshot](b7n/08-validation/viewport.png) · [Validation ARIA snapshot](b7n/08-validation/aria.yml) · [Validation DOM](b7n/verification/05-validation-rendered-elements.json) · [Validation Chromium tree](b7n/verification/05-validation-chromium-ax.json) · [Confirmation screenshot](b7n/12-confirmation/viewport.png) · [Complete keyboard trace](b7n/verification/keyboard-and-navigation.json)

## h2v

The error element was `p#error[role="alert"]`. The empty alert was already present in the Chromium tree before entry. On validation the message appeared under the alert, which Chromium exposed with `live: assertive` and `atomic: true`. The same message also served as the textbox description.

[Dates screenshot](h2v/05-date-focus/viewport.png) · [Validation screenshot](h2v/08-validation/viewport.png) · [Validation ARIA snapshot](h2v/08-validation/aria.yml) · [Validation DOM](h2v/verification/05-validation-rendered-elements.json) · [Validation Chromium tree](h2v/verification/05-validation-chromium-ax.json) · [Confirmation screenshot](h2v/12-confirmation/viewport.png) · [Complete keyboard trace](h2v/verification/keyboard-and-navigation.json)

## Usability improvement

Show the two-person minimum as persistent help beside `見学人数`, such as `2名以上でお申し込みください。`, and associate that help with the textbox. On both pages the minimum first appeared after the attempt with one person, so this would let first-time visitors see the requirement before entering a value. The correction left the earlier error text visible and the textbox exposed as invalid until review was activated again.

[Initial guest form](b7n/06-guests-initial/viewport.png) · [Corrected value with lingering error](b7n/10-corrected-input/viewport.png)

## Method and evidence

I used trusted Playwright keyboard input in headless Chromium with separate fresh contexts, 1280 × 900 CSS pixels, and device scale factor 1. Each first walkthrough started at its entry URL. The numbered folders record screenshots, rendered text, accessibility snapshots, public DOM attributes, and focus-state details. Some first-pass keyboard log entries lack after-focus samples because the browser was still navigating. The destination captures succeeded, and a fresh verification run recorded all 15 keystrokes and destination states for each page. That run also captured Chromium's public accessibility tree. The accessibility observations describe the browser tree. Screen-reader speech was outside this check.

[Browser settings](method.json)
