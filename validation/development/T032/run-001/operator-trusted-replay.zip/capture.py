"""Replay the observed booking path and capture actual browser keyboard events."""
import json
from datetime import datetime, timezone
from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parent
STORE_KEY = "__t032_operator_trusted_keyboard_replay"
ENTRY = "http://127.0.0.1:43933/"
DATE = "2026-12-20"

INIT_SCRIPT = r"""
(() => {
  if (window !== window.top) return;
  const storageKey = "__t032_operator_trusted_keyboard_replay";
  function describe(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) {
      return {nodeName: element?.nodeName ?? null};
    }
    const label = element.labels?.[0]?.innerText ?? null;
    const text = ["BODY", "HTML", "INPUT"].includes(element.tagName)
      ? null : element.innerText?.trim().slice(0, 150) ?? null;
    return {
      tag: element.tagName,
      id: element.id || null,
      text,
      label,
      value: element instanceof HTMLInputElement ? element.value : null
    };
  }
  function record(event) {
    const entries = JSON.parse(sessionStorage.getItem(storageKey) || "[]");
    entries.push({
      index: entries.length + 1,
      type: event.type,
      key: event.key,
      code: event.code,
      isTrusted: event.isTrusted,
      url: location.href,
      mainFrame: window === window.top,
      eventTimestamp: event.timeStamp,
      eventTimeOrigin: performance.timeOrigin,
      target: describe(event.target),
      focus: describe(document.activeElement),
      modifiers: {
        ctrl: event.ctrlKey,
        shift: event.shiftKey,
        alt: event.altKey,
        meta: event.metaKey
      }
    });
    sessionStorage.setItem(storageKey, JSON.stringify(entries));
  }
  window.addEventListener("keydown", record, {capture: true, passive: true});
  window.addEventListener("keyup", record, {capture: true, passive: true});
})();
"""

STATE_SCRIPT = r"""
() => {
  const input = document.querySelector("#people");
  const error = document.querySelector("#error");
  return {
    url: location.href,
    title: document.title,
    heading: document.querySelector("h1")?.innerText ?? null,
    focus: {
      tag: document.activeElement.tagName,
      id: document.activeElement.id || null
    },
    input: input ? {
      value: input.value,
      describedBy: input.getAttribute("aria-describedby"),
      invalid: input.getAttribute("aria-invalid")
    } : null,
    error: error ? {
      text: error.innerText,
      role: error.getAttribute("role"),
      live: error.getAttribute("aria-live")
    } : null,
    visibleText: document.body.innerText
  };
}
"""


def save_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def replay(browser, variant):
    folder = ROOT / variant
    folder.mkdir(exist_ok=True)
    context = browser.new_context(
        viewport={"width": 1280, "height": 900},
        device_scale_factor=1,
        locale="en-US",
        timezone_id="UTC",
    )
    context.add_init_script(INIT_SCRIPT)
    page = context.new_page()
    entry_url = ENTRY + variant + "/"
    guests_url = entry_url + f"guests.html?date={DATE}"
    confirmation_url = entry_url + f"check.html?date={DATE}&people=2"
    entry_response = page.goto(entry_url, wait_until="load")
    assert entry_response.status == 200, entry_url

    def browser_events():
        return page.evaluate("key => JSON.parse(sessionStorage.getItem(key) || '[]')", STORE_KEY)

    actions = []

    def key(press, *, destination=None, stage=None):
        before_count = len(browser_events())
        before = page.evaluate(STATE_SCRIPT)
        page.keyboard.press(press)
        if destination:
            page.wait_for_url(destination, wait_until="load")
        after = page.evaluate(STATE_SCRIPT)
        new_events = browser_events()[before_count:]
        action = {
            "actionIndex": len(actions) + 1,
            "press": press,
            "stage": stage,
            "relatedEventIndexes": [event["index"] for event in new_events],
            "before": before,
            "after": after,
        }
        if stage:
            screenshot = f"{stage}.png"
            page.screenshot(path=folder / screenshot)
            action["screenshot"] = screenshot
        actions.append(action)

    key("Tab")
    key("Enter")
    key("Tab")
    key("Enter", destination=entry_url + "dates.html")
    key("Tab")
    key("Enter", destination=guests_url)
    key("Tab")
    key("1")
    key("Tab")
    key("Enter", stage="01-one-person-validation")
    assert actions[-1]["after"]["url"] == guests_url
    assert actions[-1]["after"]["focus"]["id"] == "review"
    assert actions[-1]["after"]["input"]["value"] == "1"
    assert actions[-1]["after"]["input"]["invalid"] == "true"
    assert actions[-1]["after"]["error"]["text"] == "見学人数は2名以上を入力してください。"
    key("Shift+Tab")
    key("Control+a")
    key("2", stage="02-corrected-value")
    assert actions[-1]["after"]["input"]["value"] == "2"
    key("Tab")
    key("Enter", destination=confirmation_url, stage="03-confirmation")
    assert actions[-1]["after"]["heading"] == "見学予約の確認"
    assert "12月20日。見学人数 2 名。" in actions[-1]["after"]["visibleText"]

    events = browser_events()
    assert all(event["mainFrame"] and event["isTrusted"] for event in events)
    assert all(action["relatedEventIndexes"] for action in actions)
    save_json(folder / "keyboard-events.json", events)
    save_json(folder / "actions-and-outcomes.json", actions)
    print(
        f"{variant}: {len(events)} trusted main-frame events across {len(actions)} "
        f"actions and confirmation at {confirmation_url}",
        flush=True,
    )
    context.close()
    return {
        "entry": entry_url,
        "confirmation": confirmation_url,
        "events": len(events),
        "keydown": sum(event["type"] == "keydown" for event in events),
        "keyup": sum(event["type"] == "keyup" for event in events),
        "allTrue": all(event["isTrusted"] for event in events),
    }


with sync_playwright() as playwright:
    browser = playwright.chromium.launch(executable_path="/usr/bin/chromium", headless=True)
    results = {variant: replay(browser, variant) for variant in ("b7n", "h2v")}
    save_json(
        ROOT / "method-and-counts.json",
        {
            "capturedUtc": datetime.now(timezone.utc).isoformat(),
            "browser": "Chromium " + browser.version,
            "headless": True,
            "viewportCssPixels": [1280, 900],
            "separateFreshContexts": True,
            "input": "Playwright page.keyboard.press",
            "capture": "Main-frame passive capture-phase keydown and keyup observers with sessionStorage persistence across same-origin navigation.",
            "results": results,
        },
    )
    browser.close()
