# 修正担当向けの不適合記録

この記録は検証結果です。製品コードの変更は行っていません。

予定範囲の検査完了: いいえ
結果: 未実施 110
全基準と範囲の未確認は[HTMLレポート](page-dcaf80e1ce9a-report.html)又は[JSON](page-dcaf80e1ce9a-report.json)を参照してください。
